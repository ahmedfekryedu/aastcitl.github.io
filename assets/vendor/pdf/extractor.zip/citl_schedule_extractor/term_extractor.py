from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path

import pdfplumber

from .common import ExtractionResult, ProgressCallback, noop_progress, prepare_output_dir


TABLE_NAME = "public.academic_schedule"
TIME_MAPPING = {
    1: "08:30 - 09:20",
    2: "09:30 - 10:20",
    3: "10:30 - 11:20",
    4: "11:30 - 12:20",
    5: "12:30 - 13:20",
    6: "13:30 - 14:20",
    7: "14:30 - 15:20",
    8: "15:30 - 16:20",
    9: "16:30 - 17:20",
    10: "17:30 - 18:20",
}
CODE_LINE_RE = re.compile(r"^\d+/|/\d+/|[A-Z]{1,3}\d*/|/[A-Z]{1,3}\d*", re.IGNORECASE)
ONLY_CODE_TOKEN_RE = re.compile(r"^[A-Z]{1,3}\d*$")
INSTRUCTOR_RE = re.compile(r"^(Dr\.|Mr\.|Ms\.|Mrs\.|Prof\.|Eng\.|Admiral\.)", re.IGNORECASE)
ROOM_RE = re.compile(r"\b(?:H|G|PH|IMO|M|ENG)\s?\d+(?:\s?[A-Za-z]+)?\b(?#CITL_ROOM_FIX_V2)", re.IGNORECASE)


def clean_text(text: str | None) -> str:
    if not text:
        return ""
    return str(text).replace("'", "''").strip()


def normalize_code(code_lines: list[str]) -> str:
    if not code_lines:
        return ""
    joined = " ".join(code_lines)
    return re.sub(r"\s+", " ", joined).strip()


def convert_term_pdf(
    pdf_path: Path,
    output_dir: Path | None = None,
    progress: ProgressCallback = noop_progress,
) -> ExtractionResult:
    source_path = Path(pdf_path)
    if not source_path.exists():
        raise FileNotFoundError(f"الملف غير موجود: {source_path}")

    target_dir = prepare_output_dir(output_dir, source_path)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    sql_path = target_dir / f"academic_schedule_{timestamp}.sql"

    sql_statements = [f"TRUNCATE TABLE {TABLE_NAME};", ""]
    total_rows = 0

    progress(f"بدأ تحويل جدول الترم من الملف: {source_path.name}")

    with pdfplumber.open(source_path) as pdf:
        for page_index, page in enumerate(pdf.pages, start=1):
            progress(f"جاري معالجة الصفحة {page_index}/{len(pdf.pages)} من ملف الترم.")
            text = page.extract_text() or ""
            lines = text.splitlines()

            room_name = "Unknown Room"
            for line in lines:
                if ROOM_RE.search(line) and "College" not in line and "International" not in line and "Timetable" not in line:
                    room_name = line.strip()
                    break

            tables = page.extract_tables()
            for table in tables:
                if len(table) < 3:
                    continue

                days_map = {
                    "Sat": "Saturday",
                    "Sun": "Sunday",
                    "Mon": "Monday",
                    "Tue": "Tuesday",
                    "Wed": "Wednesday",
                    "Thu": "Thursday",
                }

                for row in table:
                    day_cell = str(row[0]).strip() if row and row[0] is not None else ""
                    current_day = None
                    for short_day, full_day in days_map.items():
                        if short_day in day_cell:
                            current_day = full_day
                            break
                    if not current_day:
                        continue

                    for column_index, cell_content in enumerate(row[1:], start=1):
                        if not cell_content or not str(cell_content).strip():
                            continue

                        lines_in_cell = [line.strip() for line in str(cell_content).splitlines() if line.strip()]
                        course_parts: list[str] = []
                        code_lines: list[str] = []
                        instructor = "غير محدد"

                        for line in lines_in_cell:
                            if INSTRUCTOR_RE.match(line):
                                instructor = line
                                continue

                            if "/" in line and (CODE_LINE_RE.search(line) or re.search(r"\d+/", line)):
                                code_lines.append(line)
                                continue

                            if code_lines and ONLY_CODE_TOKEN_RE.match(line):
                                code_lines.append(line)
                                continue

                            course_parts.append(line)

                        course_name = " ".join(course_parts).strip()
                        course_code = normalize_code(code_lines)

                        if not course_name and instructor == "غير محدد" and not course_code:
                            continue

                        time_slot = TIME_MAPPING.get(column_index, f"Period {column_index}")
                        sql = (
                            f"INSERT INTO {TABLE_NAME} "
                            "(room_name, day_of_week, period_order, time_slot, course_name, course_code, instructor) "
                            "VALUES "
                            f"('{clean_text(room_name)}', '{current_day}', {column_index}, '{time_slot}', "
                            f"'{clean_text(course_name)}', '{clean_text(course_code)}', '{clean_text(instructor)}');"
                        )

                        sql_statements.append(sql)
                        total_rows += 1

    sql_path.write_text("\n".join(sql_statements), encoding="utf-8")
    progress(f"تم حفظ ملف SQL: {sql_path.name}")
    progress(f"اكتمل تحويل جدول الترم. عدد السجلات المستخرجة: {total_rows}")

    return ExtractionResult(
        mode_label="جداول الترم",
        sql_path=sql_path,
        record_count=total_rows,
    )
