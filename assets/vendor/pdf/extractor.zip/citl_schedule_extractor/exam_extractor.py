from __future__ import annotations

import json
import re
import sys
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Sequence

import pdfplumber

from .common import ExtractionResult, ProgressCallback, noop_progress, prepare_output_dir


TABLE_NAME = "public.exam_schedule"
CUSTOM_CORRECTIONS_FILE = "custom_corrections.json"
SKIPPED_LOG = "skipped_exam_lines.log"
VALIDATION_REPORT = "validation_report.txt"
LANGUAGE_REVIEW_REPORT = "language_review_report.txt"
LATEST_SQL = "perfect_exam_schedule.sql"
SUMMARY_REPORT = "exam_extraction_report.txt"

DAYS = r"(?:Sat|Sun|Mon|Tue|Wed|Thu|Fri)"
MONTHS = r"(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)"
LANGS = r"[AELael]"
HARAKAT = "\u064B-\u065F\u0670"

ARABIC_DIGITS_MAP = str.maketrans(
    {
        "٠": "0",
        "١": "1",
        "٢": "2",
        "٣": "3",
        "٤": "4",
        "٥": "5",
        "٦": "6",
        "٧": "7",
        "٨": "8",
        "٩": "9",
        "۰": "0",
        "۱": "1",
        "۲": "2",
        "۳": "3",
        "۴": "4",
        "۵": "5",
        "۶": "6",
        "۷": "7",
        "۸": "8",
        "۹": "9",
    }
)

PDF_STRUCTURAL_REPLACEMENTS = {
    "LSِِA2701": "LSA2701",
    "LSِA2701": "LSA2701",
    "LS ِِA2701": "LSA2701",
    "LS ِA2701": "LSA2701",
    "LSA 2701": "LSA2701",
    "1072AِِA LS": "LSA2701",
    "1072AِA LS": "LSA2701",
}

GENERAL_TEXT_REPLACEMENTS = {
    "األ": "الأ",
    "اإل": "الإ",
    "اآل": "الآ",
    "اأ": "أ",
    "اإ": "إ",
    "اآ": "آ",
    "اال": "الا",
    "االختبارات": "الاختبارات",
    "االعمال": "الأعمال",
    "األعمال": "الأعمال",
    "االدارة": "الإدارة",
    "الادارة": "الإدارة",
    "اإلدارة": "الإدارة",
    "ادارة": "إدارة",
    "اإلنسان": "الإنسان",
    "اإلنجليزية": "الإنجليزية",
    "األكاديمية": "الأكاديمية",
    "واالتصاالت": "والاتصالات",
    "االتصاالت": "الاتصالات",
    "اإلتصال": "الاتصال",
    "الإتصال": "الاتصال",
    "سالسل": "سلاسل",
    "مبادىء": "مبادئ",
    "العالقات": "العلاقات",
    "عالقات": "علاقات",
    "العمالء": "العملاء",
    "لألغراض": "للأغراض",
    "الدولى": "الدولي",
    "مقدمه": "مقدمة",
    "االمداد": "الإمداد",
    "االنتاج": "الإنتاج",
    "االحصاء": "الإحصاء",
    "واالستيراد": "والاستيراد",
    "االقتصاد": "الاقتصاد",
    "االدارية": "الإدارية",
    "اساسيات": "أساسيات",
    "الجزئى": "الجزئي",
    "فى": "في",
    "Poltitics": "Politics",
    "poltitics": "Politics",
    "oil and gas Industry": "Oil and Gas Industry",
    "Oil and gas Industry": "Oil and Gas Industry",
}

COMMON_NAME_TEXT_REPLACEMENTS = {
    "الاء": "آلاء",
    "االء": "آلاء",
    "إسالم": "إسلام",
    "اسالم": "إسلام",
    "ايمان": "إيمان",
}

SUSPICIOUS_LANGUAGE_PATTERNS = [
    r"اأ",
    r"اإ",
    r"اآ",
    r"اال",
    r"سالسل",
    r"مبادىء",
    r"Poltitics",
    r"العالقات",
    r"العمالء",
    r"لألغراض",
    r"الدولى",
    r"مقدمه",
]

ACTIVE_CUSTOM_CORRECTIONS: dict[str, str] = {}
ACTIVE_CUSTOM_CORRECTIONS_LOADED = False
ACTIVE_CUSTOM_CORRECTIONS_PATH: Path | None = None


def normalize_spaces(text: str | None) -> str:
    if text is None:
        return ""
    return re.sub(r"\s+", " ", str(text)).strip()


def normalize_digits(value: str | None) -> str:
    return normalize_spaces(value).translate(ARABIC_DIGITS_MAP)


def remove_arabic_diacritics(text: str | None) -> str:
    return re.sub(f"[{HARAKAT}]", "", str(text or ""))


def contains_arabic(text: str) -> bool:
    return bool(re.search(r"[\u0600-\u06FF]", text))


def contains_english(text: str) -> bool:
    return bool(re.search(r"[A-Za-z]", text))


def sql_escape(value: str | None) -> str:
    return normalize_spaces(value).replace("'", "''")


def get_runtime_base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent.parent


def reverse_mixed_arabic_text(text: str) -> str:
    reversed_text = text[::-1]
    reversed_text = reversed_text.translate(str.maketrans("()[]{}<>", ")(][}{><"))
    return re.sub(
        r"[A-Za-z]+(?:\s+[A-Za-z]+)*",
        lambda match: match.group(0)[::-1],
        reversed_text,
    )


def apply_replacements(text: str, replacements: dict[str, str]) -> str:
    result = text
    sorted_items = sorted(
        (
            (normalize_spaces(source), normalize_spaces(target))
            for source, target in replacements.items()
            if normalize_spaces(source)
        ),
        key=lambda item: len(item[0]),
        reverse=True,
    )

    for source, target in sorted_items:
        if contains_english(source):
            pattern = re.compile(rf"(?<![A-Za-z]){re.escape(source)}(?![A-Za-z])", re.IGNORECASE)
            result = pattern.sub(target, result)
        else:
            result = result.replace(source, target)

    return result


def load_custom_corrections() -> dict[str, str]:
    global ACTIVE_CUSTOM_CORRECTIONS
    global ACTIVE_CUSTOM_CORRECTIONS_LOADED
    global ACTIVE_CUSTOM_CORRECTIONS_PATH

    ACTIVE_CUSTOM_CORRECTIONS = {}
    ACTIVE_CUSTOM_CORRECTIONS_LOADED = False
    ACTIVE_CUSTOM_CORRECTIONS_PATH = None

    corrections_path = get_runtime_base_dir() / CUSTOM_CORRECTIONS_FILE
    if not corrections_path.exists():
        return ACTIVE_CUSTOM_CORRECTIONS

    try:
        data = json.loads(corrections_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return ACTIVE_CUSTOM_CORRECTIONS

    if not isinstance(data, dict):
        return ACTIVE_CUSTOM_CORRECTIONS

    cleaned_replacements: dict[str, str] = {}
    for source, target in data.items():
        if not isinstance(source, str) or not isinstance(target, str):
            continue
        normalized_source = normalize_spaces(source)
        normalized_target = normalize_spaces(target)
        if normalized_source:
            cleaned_replacements[normalized_source] = normalized_target

    ACTIVE_CUSTOM_CORRECTIONS = cleaned_replacements
    ACTIVE_CUSTOM_CORRECTIONS_LOADED = True
    ACTIVE_CUSTOM_CORRECTIONS_PATH = corrections_path
    return ACTIVE_CUSTOM_CORRECTIONS


def clean_display_text(text: str | None, is_arabic_context: bool = True) -> str:
    if not text:
        return "غير محدد"

    cleaned = normalize_spaces(text)
    cleaned = normalize_digits(cleaned)

    if contains_arabic(cleaned) and is_arabic_context:
        cleaned = reverse_mixed_arabic_text(cleaned)
        cleaned = normalize_digits(cleaned)

    cleaned = remove_arabic_diacritics(cleaned)
    cleaned = apply_replacements(cleaned, PDF_STRUCTURAL_REPLACEMENTS)
    cleaned = apply_replacements(cleaned, GENERAL_TEXT_REPLACEMENTS)
    cleaned = apply_replacements(cleaned, COMMON_NAME_TEXT_REPLACEMENTS)
    cleaned = apply_replacements(cleaned, ACTIVE_CUSTOM_CORRECTIONS)
    cleaned = normalize_spaces(cleaned)
    return cleaned or "غير محدد"


def fix_text_direction_and_clean(text: str | None, reverse_if_arabic: bool = True) -> str:
    return clean_display_text(text, is_arabic_context=reverse_if_arabic)


def normalize_room(room: str) -> str:
    room = normalize_digits(normalize_spaces(room)).replace(" ", "")
    room = re.sub(r"[^A-Za-z0-9]", "", room).upper()

    number_then_prefix = re.fullmatch(r"(\d{1,3})([A-Z]{1,5})", room)
    if number_then_prefix:
        number, prefix = number_then_prefix.group(1), number_then_prefix.group(2)
        if prefix == "IMO":
            number = number.zfill(2)
        return f"{prefix}{number}"

    prefix_then_number = re.fullmatch(r"([A-Z]{1,5})(\d{1,3})", room)
    if prefix_then_number:
        prefix, number = prefix_then_number.group(1), prefix_then_number.group(2)
        if prefix == "IMO":
            number = number.zfill(2)
        return f"{prefix}{number}"

    return sql_escape(room)


def normalize_course_code(code: str) -> str:
    compact = normalize_digits(normalize_spaces(code))
    compact = apply_replacements(compact, PDF_STRUCTURAL_REPLACEMENTS)
    compact = remove_arabic_diacritics(compact).replace(" ", "").upper()
    compact = re.sub(r"[^A-Z0-9]", "", compact)

    if "LSA" in compact and "2701" in compact:
        return "LSA2701"
    if "ASL" in compact and "1072" in compact:
        return "LSA2701"

    normal = re.fullmatch(r"([A-Z]{2,5})(\d{3,4})", compact)
    if normal:
        return f"{normal.group(1)}{normal.group(2)}"

    reversed_code = re.fullmatch(r"(\d{3,4})([A-Z]{2,5})", compact)
    if reversed_code:
        return f"{reversed_code.group(2)}{reversed_code.group(1)}"

    return sql_escape(compact) if compact else "N/A"


def format_date(date_str: str, year: int, fallback_date: str) -> str:
    cleaned = normalize_spaces(date_str)
    formats = ["%a %d %b %Y", "%b %d %a %Y"]

    for fmt in formats:
        try:
            return datetime.strptime(f"{cleaned} {year}", fmt).strftime("%Y-%m-%d")
        except ValueError:
            continue

    return fallback_date


def fix_probable_pdf_am_pm_error(start_raw: str, end_raw: str) -> tuple[str, str]:
    start_raw = normalize_spaces(start_raw).upper()
    end_raw = normalize_spaces(end_raw).upper()

    time_re = r"^(\d{1,2}):(\d{2})\s*(AM|PM)$"
    start_match = re.fullmatch(time_re, start_raw)
    end_match = re.fullmatch(time_re, end_raw)

    if start_match and end_match:
        start_hour = int(start_match.group(1))
        end_hour = int(end_match.group(1))
        start_suffix = start_match.group(3)
        end_suffix = end_match.group(3)

        if start_suffix == "AM" and end_suffix == "AM" and 1 <= start_hour <= 5 and 2 <= end_hour <= 6:
            start_raw = f"{start_match.group(1)}:{start_match.group(2)} PM"
            end_raw = f"{end_match.group(1)}:{end_match.group(2)} PM"

    return start_raw, end_raw


def to_24h(start_raw: str, end_raw: str) -> tuple[str, str]:
    start_raw, end_raw = fix_probable_pdf_am_pm_error(start_raw, end_raw)
    try:
        start_time = datetime.strptime(start_raw, "%I:%M %p").strftime("%H:%M:%S")
        end_time = datetime.strptime(end_raw, "%I:%M %p").strftime("%H:%M:%S")
        return start_time, end_time
    except ValueError:
        return "00:00:00", "00:00:00"


def split_without_group_normal(remaining: str) -> tuple[str, str, str]:
    remaining = normalize_spaces(remaining)
    parts = remaining.split()

    for index, part in enumerate(parts):
        if index > 0 and contains_english(part) and any(contains_arabic(item) for item in parts[:index]):
            instructor = " ".join(parts[:index])
            course = " ".join(parts[index:])
            if instructor and course:
                return "1", instructor, course

    return "1", remaining, ""


def split_without_group_reversed(middle: str) -> tuple[str, str, str]:
    middle = normalize_spaces(middle)
    parts = middle.split()

    for index, part in enumerate(parts):
        if index > 0 and contains_arabic(part) and any(contains_english(item) for item in parts[:index]):
            course = " ".join(parts[:index])
            instructor = " ".join(parts[index:])
            if instructor and course:
                return "1", instructor, course

    return "1", "", middle


def split_by_group_normal(remaining: str) -> tuple[str, str, str]:
    parts = normalize_spaces(remaining).split()
    group_number = "1"
    instructor_parts: list[str] = []
    course_parts: list[str] = []
    found_group = False

    for part in parts:
        clean = normalize_digits(part)
        if not found_group and re.fullmatch(r"\d+", clean):
            group_number = clean
            found_group = True
        elif not found_group:
            instructor_parts.append(part)
        else:
            course_parts.append(part)

    if found_group:
        return group_number, " ".join(instructor_parts), " ".join(course_parts)

    return split_without_group_normal(remaining)


def split_by_group_reversed_middle(middle: str) -> tuple[str, str, str]:
    parts = normalize_spaces(middle).split()
    group_number = "1"
    course_parts: list[str] = []
    instructor_parts: list[str] = []
    found_group = False

    for part in parts:
        clean = normalize_digits(part)
        if not found_group and re.fullmatch(r"\d+", clean):
            group_number = clean
            found_group = True
        elif not found_group:
            course_parts.append(part)
        else:
            instructor_parts.append(part)

    if found_group:
        return group_number, " ".join(instructor_parts), " ".join(course_parts)

    return split_without_group_reversed(middle)


def preclean_line_for_parsing(line: str) -> str:
    cleaned = normalize_spaces(line)
    cleaned = normalize_digits(cleaned)
    cleaned = apply_replacements(cleaned, PDF_STRUCTURAL_REPLACEMENTS)
    return normalize_spaces(cleaned)


def rescue_lsa2701_from_course_name(row: dict[str, str]) -> dict[str, str]:
    course_name = row.get("course_name", "")
    course_code = row.get("course_code", "")

    compact = re.sub(r"\s+", "", remove_arabic_diacritics(course_name)).upper()

    if course_code == "N/A" and (("LSA2701" in compact) or ("1072ASL" in compact) or ("1072AALS" in compact)):
        row["course_code"] = "LSA2701"
        cleaned_course = re.sub(r"\bLS\s*A\s*2701\b", "", course_name, flags=re.IGNORECASE)
        cleaned_course = re.sub(r"\b2701\s*A\s*SL\b", "", cleaned_course, flags=re.IGNORECASE)
        cleaned_course = re.sub(r"1072\s*A+\s*LS", "", cleaned_course, flags=re.IGNORECASE)
        cleaned_course = normalize_spaces(remove_arabic_diacritics(cleaned_course))
        row["course_name"] = cleaned_course or "إدارة سلاسل الإمداد"

    return row


def parse_normal_line(line: str, year: int, fallback_date: str) -> dict[str, str] | None:
    line = preclean_line_for_parsing(line)

    room_match = re.match(r"^([A-Za-z]{1,5}\s*\d{1,3})\s+", line)
    if not room_match:
        return None

    room = normalize_room(room_match.group(1))
    remaining = line[room_match.end():].strip()

    count_match = re.match(r"^(\d+)\s+", remaining)
    if not count_match:
        return None

    count = normalize_digits(count_match.group(1))
    remaining = remaining[count_match.end():].strip()

    times = re.findall(r"\d{1,2}:\d{2}\s*(?:AM|PM|am|pm)", remaining)
    if len(times) < 2:
        return None

    end_raw = times[0]
    start_raw = times[1]
    remaining = remaining.replace(end_raw, "", 1).replace(start_raw, "", 1).strip()
    start_time, end_time = to_24h(start_raw, end_raw)

    date_match = re.search(rf"{DAYS}\s+\d{{1,2}}\s+{MONTHS}", remaining, re.IGNORECASE)
    exam_date = fallback_date
    if date_match:
        date_str = date_match.group(0)
        exam_date = format_date(date_str, year, fallback_date)
        remaining = remaining.replace(date_str, "", 1).strip()

    level_match = re.search(r"\s+(\d+)$", remaining)
    if not level_match:
        return None

    academic_level = normalize_digits(level_match.group(1))
    remaining = remaining[:level_match.start()].strip()

    code_lang_match = re.search(
        rf"\s+([A-Za-z{HARAKAT}]{{2,8}}\s*\d{{3,4}}|\d{{3,4}}\s*[A-Za-z{HARAKAT}]{{2,8}})\s+({LANGS})$",
        remaining,
    )

    if code_lang_match:
        course_code = normalize_course_code(code_lang_match.group(1))
        course_language = code_lang_match.group(2).upper()
        remaining = remaining[:code_lang_match.start()].strip()
    else:
        code_match = re.search(
            rf"\s+([A-Za-z{HARAKAT}]{{2,8}}\s*\d{{3,4}}|\d{{3,4}}\s*[A-Za-z{HARAKAT}]{{2,8}})$",
            remaining,
        )
        if not code_match:
            return None

        course_code = normalize_course_code(code_match.group(1))
        remaining = remaining[:code_match.start()].strip()

        language_match = re.search(rf"\s+({LANGS})$", remaining)
        if not language_match:
            return None

        course_language = language_match.group(1).upper()
        remaining = remaining[:language_match.start()].strip()

    group_number, instructor_raw, course_raw = split_by_group_normal(remaining)

    row = {
        "academic_level": academic_level,
        "course_code": course_code,
        "course_language": course_language,
        "course_name": fix_text_direction_and_clean(course_raw, reverse_if_arabic=True),
        "group_number": normalize_digits(group_number),
        "instructor": fix_text_direction_and_clean(instructor_raw, reverse_if_arabic=True),
        "exam_date": exam_date,
        "start_time": start_time,
        "end_time": end_time,
        "student_count": count,
        "room_name": room,
    }

    return rescue_lsa2701_from_course_name(row)


def parse_reversed_line(line: str, year: int, fallback_date: str) -> dict[str, str] | None:
    line = preclean_line_for_parsing(line)
    date_pattern = rf"(?:(?:{DAYS}\s+\d{{1,2}}\s+{MONTHS})|(?:{MONTHS}\s+\d{{1,2}}\s+{DAYS}))"

    pattern = re.compile(
        rf"^(?P<level>\d+)\s+"
        rf"(?P<code>(?:[A-Za-z{HARAKAT}]{{2,8}}\s*\d{{3,4}}|\d{{3,4}}\s*[A-Za-z{HARAKAT}]{{2,8}}))\s+"
        rf"(?P<lang>{LANGS})\s+"
        rf"(?P<middle>.+?)\s+"
        rf"(?P<date>{date_pattern})\s+"
        rf"(?P<start_suffix>AM|PM|am|pm)\s+"
        rf"(?P<start_clock>\d{{1,2}}:\d{{2}})\s+"
        rf"(?P<end_suffix>AM|PM|am|pm)\s+"
        rf"(?P<end_clock>\d{{1,2}}:\d{{2}})\s+"
        rf"(?P<count>\d+)\s+"
        rf"(?P<room>(?:\d{{1,3}}\s*[A-Za-z]{{1,5}}|[A-Za-z]{{1,5}}\s*\d{{1,3}}))$",
        re.IGNORECASE,
    )

    match = pattern.match(line)
    if not match:
        return None

    start_raw = f"{match.group('start_clock')} {match.group('start_suffix')}"
    end_raw = f"{match.group('end_clock')} {match.group('end_suffix')}"
    start_time, end_time = to_24h(start_raw, end_raw)
    group_number, instructor_raw, course_raw = split_by_group_reversed_middle(match.group("middle"))

    row = {
        "academic_level": normalize_digits(match.group("level")),
        "course_code": normalize_course_code(match.group("code")),
        "course_language": match.group("lang").upper(),
        "course_name": fix_text_direction_and_clean(course_raw, reverse_if_arabic=False),
        "group_number": normalize_digits(group_number),
        "instructor": fix_text_direction_and_clean(instructor_raw, reverse_if_arabic=False),
        "exam_date": format_date(match.group("date"), year, fallback_date),
        "start_time": start_time,
        "end_time": end_time,
        "student_count": normalize_digits(match.group("count")),
        "room_name": normalize_room(match.group("room")),
    }

    return rescue_lsa2701_from_course_name(row)


def parse_exam_line(line: str, year: int, fallback_date: str) -> dict[str, str] | None:
    return parse_normal_line(line, year, fallback_date) or parse_reversed_line(line, year, fallback_date)


def is_exam_like_line(line: str) -> bool:
    cleaned = normalize_spaces(line)
    lowered = cleaned.lower()

    header_markers = [
        "college of international transport logistics",
        "citl",
        "جدول",
        "الاختبارات",
        "الامتحانات",
        "اليوم",
        "م/ص",
        "ص/م",
    ]
    if any(marker in lowered for marker in header_markers):
        return False

    return bool(re.search(r"\d{1,2}:\d{2}|[A-Za-z]{1,5}\s*\d{1,4}|\d{1,4}\s*[A-Za-z]{1,5}", cleaned))


def row_unique_key(row: dict[str, str]) -> tuple[str, ...]:
    return (
        row["academic_level"],
        row["course_code"],
        row["course_language"],
        row["course_name"],
        row["group_number"],
        row["instructor"],
        row["exam_date"],
        row["start_time"],
        row["end_time"],
        row["student_count"],
        row["room_name"],
    )


def build_sql(row: dict[str, str]) -> str:
    student_count = normalize_digits(row.get("student_count", "0"))
    if not student_count.isdigit():
        student_count = "0"

    course_name = clean_display_text(row["course_name"], is_arabic_context=False)
    instructor = clean_display_text(row["instructor"], is_arabic_context=False)

    return (
        f"INSERT INTO {TABLE_NAME} "
        "(academic_level, course_code, course_language, course_name, group_number, "
        "instructor, exam_date, start_time, end_time, student_count, room_name) "
        "VALUES ("
        f"'{sql_escape(row['academic_level'])}', "
        f"'{sql_escape(row['course_code'])}', "
        f"'{sql_escape(row['course_language'])}', "
        f"'{sql_escape(course_name)}', "
        f"'{sql_escape(row['group_number'])}', "
        f"'{sql_escape(instructor)}', "
        f"'{sql_escape(row['exam_date'])}', "
        f"'{sql_escape(row['start_time'])}', "
        f"'{sql_escape(row['end_time'])}', "
        f"{student_count}, "
        f"'{sql_escape(row['room_name'])}'"
        ");"
    )


def validate_rows(
    rows: list[dict[str, str]],
    skipped_lines: list[str],
    fallback_date: str,
) -> tuple[list[str], list[str]]:
    issues: list[str] = []
    language_hits: list[str] = []
    seen: set[tuple[str, ...]] = set()

    for index, row in enumerate(rows, start=1):
        key = row_unique_key(row)
        if key in seen:
            issues.append(f"Row {index}: duplicate row detected: {key}")
        seen.add(key)

        if not row.get("course_code") or row.get("course_code") == "N/A":
            issues.append(f"Row {index}: missing course_code | {row}")

        if row.get("course_name") in ("", "غير محدد"):
            issues.append(f"Row {index}: missing course_name | {row}")

        if row.get("instructor") in ("", "غير محدد"):
            issues.append(f"Row {index}: missing instructor | {row}")

        if row.get("exam_date") == fallback_date:
            issues.append(f"Row {index}: fallback date used | {row}")

        if row.get("start_time") == "00:00:00" or row.get("end_time") == "00:00:00":
            issues.append(f"Row {index}: zero time detected | {row}")

        try:
            start_time = datetime.strptime(row["start_time"], "%H:%M:%S")
            end_time = datetime.strptime(row["end_time"], "%H:%M:%S")
            if end_time <= start_time:
                issues.append(f"Row {index}: end_time <= start_time | {row}")
        except ValueError:
            issues.append(f"Row {index}: invalid time format | {row}")

        if re.search(r"[٠-٩۰-۹]", row.get("group_number", "")):
            issues.append(f"Row {index}: Arabic digits still exist in group_number | {row}")

        combined_text = f"{row.get('course_name', '')} {row.get('instructor', '')}"
        for pattern in SUSPICIOUS_LANGUAGE_PATTERNS:
            if re.search(pattern, combined_text):
                language_hits.append(f"Row {index}: pattern '{pattern}' => {combined_text}")

    if skipped_lines:
        issues.append(f"Skipped exam-like lines: {len(skipped_lines)}. See {SKIPPED_LOG}.")

    return issues, language_hits


def write_sql_outputs(target_dir: Path, rows: list[dict[str, str]]) -> tuple[Path, Path]:
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    sql_path = target_dir / f"exam_schedule_{timestamp}.sql"
    latest_sql_path = target_dir / LATEST_SQL

    sql_statements = [f"TRUNCATE TABLE {TABLE_NAME};", ""]
    sql_statements.extend(build_sql(row) for row in rows)
    content = "\n".join(sql_statements)

    sql_path.write_text(content, encoding="utf-8")
    latest_sql_path.write_text(content, encoding="utf-8")
    return sql_path, latest_sql_path


def write_validation_reports(
    target_dir: Path,
    rows: list[dict[str, str]],
    skipped_lines: list[str],
    validation_issues: list[str],
    language_hits: list[str],
) -> tuple[Path, Path, Path]:
    skipped_path = target_dir / SKIPPED_LOG
    validation_path = target_dir / VALIDATION_REPORT
    language_path = target_dir / LANGUAGE_REVIEW_REPORT

    skipped_path.write_text(
        "\n".join(skipped_lines) if skipped_lines else "No skipped exam-like lines.\n",
        encoding="utf-8",
    )

    with validation_path.open("w", encoding="utf-8") as file_obj:
        file_obj.write("CITL Exam Extractor Validation Report\n")
        file_obj.write("=" * 45 + "\n\n")
        file_obj.write(f"Rows extracted: {len(rows)}\n")
        file_obj.write(f"Skipped exam-like lines: {len(skipped_lines)}\n")
        file_obj.write(f"Custom corrections loaded: {ACTIVE_CUSTOM_CORRECTIONS_LOADED}\n\n")

        rows_by_date = Counter(row["exam_date"] for row in rows)
        file_obj.write("Rows by date:\n")
        for exam_date, count in sorted(rows_by_date.items()):
            file_obj.write(f"- {exam_date}: {count}\n")

        file_obj.write("\nValidation issues:\n")
        if validation_issues:
            for issue in validation_issues:
                file_obj.write(f"- {issue}\n")
        else:
            file_obj.write("No structural validation issues detected.\n")

    with language_path.open("w", encoding="utf-8") as file_obj:
        file_obj.write("Language Review Report\n")
        file_obj.write("=" * 25 + "\n\n")
        if language_hits:
            file_obj.write(
                "Suspicious language patterns still found. Add corrections to custom_corrections.json if needed:\n\n"
            )
            for hit in language_hits:
                file_obj.write(f"- {hit}\n")
        else:
            file_obj.write("No suspicious language patterns detected from the built-in watchlist.\n")

    return skipped_path, validation_path, language_path


def write_summary_report(
    target_dir: Path,
    total_rows: int,
    skipped_count: int,
    sql_path: Path,
    skipped_log_path: Path,
) -> Path:
    corrections_message = (
        f"تم تحميل {CUSTOM_CORRECTIONS_FILE} من: {ACTIVE_CUSTOM_CORRECTIONS_PATH}"
        if ACTIVE_CUSTOM_CORRECTIONS_LOADED and ACTIVE_CUSTOM_CORRECTIONS_PATH
        else "تم استخدام التصحيحات الداخلية فقط."
    )

    report_lines = [
        "تقرير استخراج جداول الإمتحانات",
        f"عدد الصفوف المستخرجة: {total_rows}",
        f"عدد السطور المتخطية: {skipped_count}",
        corrections_message,
        f"ملف SQL: {sql_path}",
        f"ملف السطور المتخطية: {skipped_log_path}",
    ]
    report_content = "\n".join(report_lines)

    runtime_report_path = get_runtime_base_dir() / SUMMARY_REPORT
    try:
        runtime_report_path.write_text(report_content, encoding="utf-8")
        if runtime_report_path.parent != target_dir:
            (target_dir / SUMMARY_REPORT).write_text(report_content, encoding="utf-8")
        return runtime_report_path
    except OSError:
        fallback_report_path = target_dir / SUMMARY_REPORT
        fallback_report_path.write_text(report_content, encoding="utf-8")
        return fallback_report_path


def extract_text_lines_from_page(page: pdfplumber.page.Page) -> list[str]:
    text = page.extract_text() or ""
    if not text:
        text = page.extract_text(layout=True) or ""
    return text.splitlines()


def sort_pdf_paths(pdf_paths: Sequence[Path]) -> list[Path]:
    def sort_key(path: Path) -> tuple[int, str]:
        digits = re.sub(r"\D", "", path.stem)
        return int(digits or 0), path.name.lower()

    return sorted((Path(path) for path in pdf_paths), key=sort_key)


def convert_exam_pdfs(
    pdf_paths: Sequence[Path],
    output_dir: Path | None = None,
    year: int | None = None,
    progress: ProgressCallback = noop_progress,
) -> ExtractionResult:
    if not pdf_paths:
        raise ValueError("لم يتم اختيار ملفات PDF لجداول الإمتحانات.")

    ordered_paths = sort_pdf_paths(pdf_paths)
    selected_year = year or datetime.now().year
    fallback_date = f"{selected_year}-06-01"
    target_dir = prepare_output_dir(output_dir, ordered_paths[0])

    load_custom_corrections()

    rows: list[dict[str, str]] = []
    skipped_lines: list[str] = []
    seen: set[tuple[str, ...]] = set()

    progress(f"بدأ تحويل {len(ordered_paths)} ملف/ملفات إمتحانات.")
    if ACTIVE_CUSTOM_CORRECTIONS_LOADED and ACTIVE_CUSTOM_CORRECTIONS_PATH:
        progress(f"تم تحميل {CUSTOM_CORRECTIONS_FILE} من: {ACTIVE_CUSTOM_CORRECTIONS_PATH}")
    else:
        progress("تم استخدام التصحيحات الداخلية فقط.")

    for file_index, file_path in enumerate(ordered_paths, start=1):
        progress(f"جاري قراءة ملف الإمتحانات {file_index}/{len(ordered_paths)}: {file_path.name}")

        with pdfplumber.open(file_path) as pdf:
            for page_number, page in enumerate(pdf.pages, start=1):
                for line in extract_text_lines_from_page(page):
                    original_line = normalize_spaces(line)
                    if not original_line:
                        continue

                    row = parse_exam_line(original_line, selected_year, fallback_date)
                    if not row:
                        if is_exam_like_line(original_line):
                            skipped_lines.append(f"[{file_path.name} - صفحة {page_number}] {original_line}")
                        continue

                    unique_key = row_unique_key(row)
                    if unique_key in seen:
                        continue

                    seen.add(unique_key)
                    rows.append(row)

    sql_path, latest_sql_path = write_sql_outputs(target_dir, rows)
    validation_issues, language_hits = validate_rows(rows, skipped_lines, fallback_date)
    skipped_path, validation_path, language_path = write_validation_reports(
        target_dir,
        rows,
        skipped_lines,
        validation_issues,
        language_hits,
    )
    report_path = write_summary_report(
        target_dir=target_dir,
        total_rows=len(rows),
        skipped_count=len(skipped_lines),
        sql_path=sql_path,
        skipped_log_path=skipped_path,
    )

    progress(f"تم حفظ ملف SQL: {sql_path.name}")
    progress(f"تم حفظ النسخة الثابتة: {latest_sql_path.name}")
    progress(f"تم حفظ ملف السطور المتخطية: {skipped_path.name}")
    progress(f"تم حفظ تقرير الفحص: {validation_path.name}")
    progress(f"تم حفظ تقرير مراجعة اللغة: {language_path.name}")
    progress(f"عدد الصفوف المستخرجة: {len(rows)}")
    progress(f"عدد السطور المتخطية: {len(skipped_lines)}")
    progress(
        f"تم تحميل {CUSTOM_CORRECTIONS_FILE} بنجاح."
        if ACTIVE_CUSTOM_CORRECTIONS_LOADED and ACTIVE_CUSTOM_CORRECTIONS_PATH
        else "لم يتم العثور على custom_corrections.json، وتم استخدام التصحيحات الداخلية فقط."
    )
    progress(f"تم حفظ التقرير: {report_path}")

    return ExtractionResult(
        mode_label="جداول الإمتحانات",
        sql_path=sql_path,
        record_count=len(rows),
        details_path=skipped_path,
        details_count=len(skipped_lines),
    )
