"""CITL desktop extractor package."""

