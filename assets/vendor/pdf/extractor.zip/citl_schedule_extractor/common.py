from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Callable


ProgressCallback = Callable[[str], None]


def noop_progress(_: str) -> None:
    """Fallback progress callback."""


def prepare_output_dir(output_dir: Path | None, source_path: Path) -> Path:
    target_dir = Path(output_dir) if output_dir else source_path.parent
    target_dir.mkdir(parents=True, exist_ok=True)
    return target_dir


@dataclass(slots=True)
class ExtractionResult:
    mode_label: str
    sql_path: Path
    record_count: int
    details_path: Path | None = None
    details_count: int = 0

